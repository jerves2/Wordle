package com.example.wordle

import android.app.Activity
import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.wordle.FourLetterWordList.FourLetterWordList.getRandomFourLetterWord

class MainActivity : AppCompatActivity() {
    lateinit var et_simple: EditText
    lateinit var firstGuessDisplay: TextView
    lateinit var guessButton: Button
    lateinit var textView8: TextView
    lateinit var textView9: TextView
    lateinit var textView10: TextView
    lateinit var textView11: TextView
    lateinit var textView12: TextView
    lateinit var answerTextView: TextView
    var wordToGuess = getRandomFourLetterWord()
    var counter = 0

    fun Fragment.hideKeyboard() {
        view?.let { activity?.hideKeyboard(it) }
    }

    fun Activity.hideKeyboard() {
        hideKeyboard(currentFocus ?: View(this))
    }

    fun Context.hideKeyboard(view: View) {
        val inputMethodManager = getSystemService(Activity.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun checkGuess(guess: String): String {
        var result = ""
        for (i in 0..3) {

            if (guess[i] == wordToGuess[i]) {
                result += "O"
            } else if (guess[i] in wordToGuess) {
                result += "+"
            } else {
                result += "X"
            }
        }
        return result
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)


        setContentView(R.layout.activity_main)

        //Toast.makeText(applicationContext, wordToGuess, Toast.LENGTH_SHORT).show()
        et_simple = findViewById<EditText>(R.id.et_simple)
        firstGuessDisplay = findViewById<TextView>(R.id.firstGuessDisplay)
        guessButton = findViewById<Button>(R.id.guessButton)
        textView8 = findViewById(R.id.textView8)
        textView9 = findViewById(R.id.textView9)
        textView10 = findViewById(R.id.textView10)
        textView11 = findViewById(R.id.textView11)
        textView12 = findViewById(R.id.textView12)
        answerTextView = findViewById(R.id.answerTextView)


        guessButton.setOnClickListener {
            counter++
            firstGuessDisplay.text = et_simple.text.toString().uppercase()
            textView8.text = checkGuess(firstGuessDisplay.text.toString().uppercase())
            Toast.makeText(it.context, firstGuessDisplay.text.toString(), Toast.LENGTH_LONG).show()
            hideKeyboard()
            if (counter == 1) {
                guessButton.setOnClickListener {
                    counter++
                    textView9.text = et_simple.text.toString().uppercase()
                    textView10.text = checkGuess(textView9.text.toString().uppercase())
                    Toast.makeText(it.context, textView9.text.toString(), Toast.LENGTH_LONG).show()
                    hideKeyboard()
                    if (counter == 2) {
                        guessButton.setOnClickListener {
                            counter++
                            textView11.text = et_simple.text.toString().uppercase()
                            textView12.text = checkGuess(textView11.text.toString().uppercase())
                            answerTextView.text = wordToGuess.uppercase()
                            Toast.makeText(it.context,counter.toString(), Toast.LENGTH_LONG).show()
                            hideKeyboard()
                        }


                    }
                }


            }


        }


//

//        guessButton.setOnClickListener {
//
//            textView11.text = et_simple.text.toString()
//            textView12.text = checkGuess(textView11.text.toString())
//            Toast.makeText(it.context, textView11.text.toString(), Toast.LENGTH_LONG).show()
//        }
    }
}
